# Panduan unggah ke GitHub

Panduan ini untuk ZIP `php2shell-halim-github-ready.zip`. Nama repositori yang
disarankan: `php2shell-halim-local-lab`.

Ekstrak ZIP terlebih dahulu. Unggah **isi folder hasil ekstraksi** ke akar
repositori. Jika hanya ZIP yang diunggah, GitHub menyimpannya sebagai satu
berkas arsip; kode dan README di dalamnya tidak otomatis diekstrak.

## Pilihan 1 — melalui browser

1. Masuk ke akun GitHub dan buka [halaman repositori baru](https://github.com/new).
2. Isi nama repositori dan deskripsi. Contoh deskripsi: `Lab PHP2Shell lokal
   dengan antarmuka simulasi bertema Lanud Halim; Docker, PHP, dan panduan Indonesia.`
3. Pilih Public atau Private sesuai kebutuhan. Paket tidak menetapkan pilihan
   visibilitas akun Anda.
4. Biarkan pilihan pembuatan README, `.gitignore`, dan lisensi awal kosong.
   Berkas paket sudah menyediakan README dan `.gitignore`.
5. Buat repositori. Langkah pembuatan ini mengikuti
   [panduan resmi GitHub](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository).
6. Pada repositori kosong, pilih tautan unggah berkas yang tersedia. Untuk
   repositori yang sudah berisi berkas, pilih **Add file → Upload files**.
7. Seret semua isi folder hasil ekstraksi ke area unggah, termasuk folder
   `lab`, `docker`, `profiles`, `docs`, `how-to-patch`, dan `out`.
8. Pastikan berkas bertitik seperti `.gitignore`, `.gitattributes`, dan
   `out/.gitkeep` juga masuk. Jika tidak terlihat, tampilkan berkas tersembunyi
   pada pengelola berkas. Jika unggahan folder melewatkannya, selesaikan commit
   pertama pada langkah 9 terlebih dahulu. Setelah itu gunakan **Add file →
   Create new file** dan salin isi berkas yang sama, atau gunakan Git.
9. Tulis pesan commit, misalnya `Add Halim local lab and documentation`, lalu
   selesaikan unggahan sesuai tombol commit/perubahan yang tersedia.

GitHub membatasi unggahan browser hingga 100 berkas sekaligus dan 25 MiB per
berkas. Paket ini berada di bawah batas tersebut. Unggahan lewat browser tidak
menerapkan normalisasi `.gitattributes`; berkas teks paket sudah disiapkan
dengan LF. Sumber: [menambahkan berkas di GitHub](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository).

## Pilihan 2 — memakai Git

Gunakan Git yang sudah terpasang dan autentikasi GitHub yang sudah Anda
konfigurasikan. Buat repositori GitHub kosong terlebih dahulu. Buka terminal
pada folder hasil ekstraksi, yaitu folder yang langsung berisi `README.md`.

```bash
git init -b main
git add .
git status --short
```

Periksa daftar berkas sebelum commit: direktori hasil hanya menyertakan
`out/.gitkeep`. Kemudian jalankan:

```bash
git commit -m "Add Halim local lab and documentation"
git remote add origin https://github.com/USERNAME/php2shell-halim-local-lab.git
git remote -v
git push -u origin main
```

Ganti `USERNAME` dan nama repositori dengan tujuan milik Anda. Gunakan URL
repositori yang disalin dari GitHub. Jangan menaruh token pada URL remote atau
di dalam berkas proyek. Jika Git meminta identitas commit, atur nama dan email
Git Anda pada komputer sendiri. Alur ini mengikuti
[panduan impor kode lokal GitHub](https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github).

Perintah di atas untuk repositori Git lokal baru dan tujuan GitHub kosong.
Untuk repositori yang sudah memiliki riwayat, gunakan checkout/repositori
tersebut dan proses branch biasa. Tidak perlu melakukan force push.

## Pemeriksaan setelah unggah

- `README.md` tampil pada halaman utama repositori dan gambar pratinjau terlihat.
- `docs/UPLOAD-GITHUB.md` dan `docs/PANDUAN-LAB.md` dapat dibuka.
- `lab/compose.yaml`, `lab.ps1`, dan `lab.sh` berada pada struktur yang sama
  dengan paket; jangan memindahkan folder `lab` ke luar akar proyek.
- `.gitignore`, `.gitattributes`, dan `out/.gitkeep` tersedia.
- Token aktivasi, output perintah, log, kredensial, dan berkas `.env` tidak masuk.
- Atribusi asal pada `README-UPSTREAM.md` dan `NOTICE.md` tetap disertakan.

`.gitignore` berlaku untuk penambahan melalui Git. Saat mengunggah melalui
browser, Anda memilih sendiri berkas yang dikirim; aturan ignore tidak menyaring
pilihan browser secara otomatis. ZIP awal ini hanya membawa `.gitkeep` di `out`.

## Mengambil kembali dan menjalankan

Dari halaman repositori, ambil source melalui unduhan ZIP atau clone ke komputer
sendiri. Jalankan lab dari folder tersebut sesuai
[panduan lab lokal](PANDUAN-LAB.md). GitHub menyimpan source; PHP dan Docker
dijalankan pada komputer lokal.

GitHub Pages adalah hosting statis HTML/CSS/JavaScript dan tidak menjalankan
runtime PHP/Docker lab ini. Sumber:
[tentang GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages).

## Kendala umum

| Kendala | Langkah yang relevan |
|---|---|
| README tidak tampil di halaman utama | Pastikan `README.md` berada di akar repositori, bukan di dalam folder pembungkus tambahan |
| Yang terlihat hanya berkas ZIP | Ekstrak paket dan unggah isinya sebagai source |
| `remote origin already exists` | Periksa `git remote -v`; gunakan remote repositori yang benar daripada menambah origin kedua |
| Push ditolak karena repositori tujuan berisi commit | Gunakan clone tujuan dan salin isi paket ke sana, lalu commit pada branch biasa |
| Repository not found / akses ditolak | Periksa URL, akun yang digunakan, dan hak akses repositori |
| Berkas bertitik hilang | Tambahkan berkas asli tersebut melalui Git atau fitur Create new file |

Tidak ada akun, repositori, token, atau unggahan GitHub yang dibuat otomatis
oleh paket ini. Penerbitan dilakukan saat Anda menjalankan langkah unggah.
