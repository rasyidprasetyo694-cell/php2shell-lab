<?php
declare(strict_types=1);

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; style-src 'self'; script-src 'self'; base-uri 'none'; form-action 'self'");

$year = gmdate('Y');
$requestId = substr(hash('sha256', (string) hrtime(true)), 0, 12);
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Portal demonstrasi bertema Lanud Halim Perdanakusuma untuk laboratorium lokal. Bukan situs resmi; seluruh konten dan ilustrasi merupakan simulasi.">
    <meta name="theme-color" content="#0b2039">
    <title>Halim Perdanakusuma — Portal Simulasi Lokal</title>
    <link rel="stylesheet" href="/assets/styles.css">
    <script src="/assets/app.js" defer></script>
</head>
<body>
    <a class="skip-link" href="#konten">Lewati ke konten</a>
    <div class="utility-bar">
        <div class="container utility-inner">
            <span class="utility-label"><span class="flag" aria-hidden="true"></span> PORTAL DEMONSTRASI KEDIRGANTARAAN</span>
            <span class="simulation-badge">SIMULASI LOKAL <span aria-hidden="true">·</span> BUKAN SITUS RESMI</span>
        </div>
    </div>
    <header class="site-header">
        <div class="container header-inner">
            <a class="brand" href="#beranda" aria-label="Halim Perdanakusuma, beranda simulasi">
                <span class="brand-symbol" aria-hidden="true"><span>H</span></span>
                <span class="brand-name"><small>LANUD</small><strong>HALIM PERDANAKUSUMA</strong><span>Portal informasi · edisi laboratorium</span></span>
            </a>
            <button class="menu-button" type="button" aria-expanded="false" aria-controls="site-nav"><span class="menu-lines" aria-hidden="true"></span><span>Menu</span></button>
            <nav class="site-nav" id="site-nav" aria-label="Navigasi utama">
                <a class="active" href="#beranda">Beranda</a><a href="#profil">Profil</a><a href="#kabar">Kabar Halim</a><a href="#galeri">Galeri</a><a class="nav-information" href="#informasi">Informasi <span aria-hidden="true">↗</span></a>
            </nav>
        </div>
    </header>

    <main id="konten">
        <section id="beranda" class="hero" aria-labelledby="hero-title">
            <img class="hero-image" src="/assets/halim-aviation.svg" alt="Ilustrasi digital pesawat angkut generik di landasan dengan hanggar di kejauhan" width="1600" height="900" fetchpriority="high">
            <div class="hero-shade" aria-hidden="true"></div>
            <div class="container hero-inner">
                <div class="hero-copy">
                    <p class="eyebrow light"><span class="eyebrow-rule" aria-hidden="true"></span> DARI HALIM, UNTUK NUSANTARA</p>
                    <h1 id="hero-title">Semangat pengabdian.<br><em>Seluas cakrawala.</em></h1>
                    <p class="hero-description">Mengenal dunia kedirgantaraan, kegiatan pangkalan, dan kebersamaan dengan masyarakat melalui sebuah portal simulasi lokal.</p>
                    <div class="hero-actions"><a class="button button-gold" href="#kabar">Jelajahi kabar Halim <span aria-hidden="true">↗</span></a><a class="hero-profile-link" href="#profil">Mengenal profil <span aria-hidden="true">→</span></a></div>
                    <p class="hero-note"><span aria-hidden="true">◎</span> Seluruh isi dan ilustrasi pada portal ini adalah contoh.</p>
                </div>
                <div class="visual-caption"><span class="caption-line" aria-hidden="true"></span><span>ILUSTRASI DIGITAL<br><strong>Bukan dokumentasi kegiatan resmi</strong></span></div>
            </div>
            <div class="hero-bottom"><span aria-hidden="true">01 / 01</span><span>CAKRAWALA PENGABDIAN</span><a href="#kabar">GULIR KE BAWAH <span aria-hidden="true">↓</span></a></div>
        </section>
        <div class="spotlight-wrap"><div class="container spotlight"><span class="spotlight-label"><span class="spotlight-dot" aria-hidden="true"></span> SOROTAN</span><p>Ruang belajar kedirgantaraan, dalam lingkungan uji yang Anda kendalikan.</p><a href="#informasi">Tentang simulasi <span aria-hidden="true">→</span></a></div></div>

        <section id="kabar" class="section container news-section" aria-labelledby="news-title">
            <div class="section-topline"><p class="eyebrow">KABAR & KEGIATAN</p><span class="section-index" aria-hidden="true">01 — INFORMASI</span></div>
            <div class="section-heading"><div><h2 id="news-title">Cerita dari Halim.</h2><p>Cuplikan kegiatan dan inspirasi kedirgantaraan. Semua berita berikut adalah konten contoh.</p></div><button class="text-button" id="show-all-news" type="button">Semua kabar <span aria-hidden="true">↗</span></button></div>
            <div class="news-filters" role="group" aria-label="Saring kabar menurut kategori">
                <button class="filter-button selected" type="button" data-filter="semua" aria-pressed="true">Semua kabar</button><button class="filter-button" type="button" data-filter="kegiatan" aria-pressed="false">Kegiatan</button><button class="filter-button" type="button" data-filter="edukasi" aria-pressed="false">Edukasi</button><button class="filter-button" type="button" data-filter="sosial" aria-pressed="false">Sosial</button>
            </div>
            <p class="screen-reader-only" id="filter-status" aria-live="polite">Menampilkan 3 kabar contoh.</p>
            <div class="news-grid">
                <article class="news-card" data-category="kegiatan">
                    <button class="news-image-button" type="button" data-article="kegiatan" aria-label="Baca berita contoh: Semangat kesiapan, dimulai dari kebersamaan"><img src="/assets/halim-aviation.svg" alt="Ilustrasi pesawat di landasan" width="640" height="420" loading="lazy"><span class="image-tag">BERITA CONTOH</span><span class="image-open" aria-hidden="true">↗</span></button>
                    <div class="news-meta"><span>KEGIATAN</span><span aria-hidden="true">/</span><span>EDISI SIMULASI</span></div>
                    <h3><button type="button" data-article="kegiatan">Semangat kesiapan, dimulai dari kebersamaan.</button></h3>
                    <p>Gambaran kegiatan pangkalan yang mengangkat kedisiplinan, kerja sama, dan semangat pengabdian.</p>
                    <button class="article-link" type="button" data-article="kegiatan">Baca selengkapnya <span aria-hidden="true">→</span></button>
                </article>
                <article class="news-card" data-category="edukasi">
                    <button class="news-image-button" type="button" data-article="edukasi" aria-label="Baca berita contoh: Mengenal pesawat, merawat mimpi di angkasa"><img src="/assets/halim-hangar.svg" alt="Ilustrasi hanggar dan pesawat untuk edukasi kedirgantaraan" width="640" height="420" loading="lazy"><span class="image-tag">BERITA CONTOH</span><span class="image-open" aria-hidden="true">↗</span></button>
                    <div class="news-meta"><span>EDUKASI</span><span aria-hidden="true">/</span><span>EDISI SIMULASI</span></div>
                    <h3><button type="button" data-article="edukasi">Mengenal pesawat, merawat mimpi di angkasa.</button></h3>
                    <p>Ruang cerita tentang ilmu penerbangan dan rasa ingin tahu generasi muda terhadap dunia dirgantara.</p>
                    <button class="article-link" type="button" data-article="edukasi">Baca selengkapnya <span aria-hidden="true">→</span></button>
                </article>
                <article class="news-card" data-category="sosial">
                    <button class="news-image-button" type="button" data-article="sosial" aria-label="Baca berita contoh: Kebersamaan yang tumbuh, pengabdian yang dekat"><img src="/assets/halim-community.svg" alt="Ilustrasi ruang pamer kedirgantaraan dan suasana kebersamaan" width="640" height="420" loading="lazy"><span class="image-tag">BERITA CONTOH</span><span class="image-open" aria-hidden="true">↗</span></button>
                    <div class="news-meta"><span>SOSIAL</span><span aria-hidden="true">/</span><span>EDISI SIMULASI</span></div>
                    <h3><button type="button" data-article="sosial">Kebersamaan yang tumbuh, pengabdian yang dekat.</button></h3>
                    <p>Contoh kisah kepedulian dan interaksi dengan masyarakat dalam suasana yang hangat dan terbuka.</p>
                    <button class="article-link" type="button" data-article="sosial">Baca selengkapnya <span aria-hidden="true">→</span></button>
                </article>
            </div>
        </section>

        <section id="profil" class="profile-section" aria-labelledby="profile-title">
            <div class="container profile-grid">
                <div class="profile-visual"><img src="/assets/halim-hangar.svg" alt="Ilustrasi arsitektur hanggar dan pesawat generik" width="800" height="700" loading="lazy"><div class="profile-stamp"><span class="stamp-wing" aria-hidden="true">✦</span><span>SEMANGAT DIRGANTARA<strong>Dedikasi. Disiplin. Pengabdian.</strong></span></div></div>
                <div class="profile-copy">
                    <p class="eyebrow">MENGENAL HALIM</p><h2 id="profile-title">Lebih dekat dengan<br>dunia kedirgantaraan.</h2>
                    <p class="profile-intro">Tampilan bertema Lanud Halim Perdanakusuma, dirancang untuk pengalaman belajar di laboratorium lokal.</p>
                    <p>Portal ini menghadirkan contoh susunan informasi pangkalan: profil, kabar kegiatan, galeri, dan ruang informasi. Nama institusi digunakan sebagai tema tampilan. Konten di sini bukan pernyataan atau publikasi resmi.</p>
                    <div class="profile-values"><div><span>01</span><p><strong>Wawasan dirgantara</strong>Ruang pengenalan dunia penerbangan.</p></div><div><span>02</span><p><strong>Semangat pengabdian</strong>Cerita contoh tentang kerja sama dan kepedulian.</p></div><div><span>03</span><p><strong>Lingkungan terkendali</strong>Seluruh materi disiapkan untuk simulasi lokal.</p></div></div>
                    <a class="text-link" href="#informasi">Baca informasi simulasi <span aria-hidden="true">↗</span></a>
                </div>
            </div>
        </section>

        <section id="galeri" class="section container gallery-section" aria-labelledby="gallery-title">
            <div class="section-topline"><p class="eyebrow">GALERI DIRGANTARA</p><span class="section-index" aria-hidden="true">02 — PERSPEKTIF</span></div>
            <div class="section-heading"><div><h2 id="gallery-title">Sudut pandang yang menginspirasi.</h2><p>Ilustrasi orisinal untuk melengkapi suasana portal. Klik gambar untuk melihat lebih dekat.</p></div><span class="gallery-counter">03 <span>ILUSTRASI</span></span></div>
            <div class="gallery-grid">
                <button class="gallery-tile gallery-main" type="button" data-gallery="landasan"><img src="/assets/halim-aviation.svg" alt="Perbesar ilustrasi: Cakrawala di atas landasan" width="1000" height="800" loading="lazy"><span class="gallery-overlay"><span><small>01 / LANDASAN</small><strong>Cakrawala di atas landasan</strong></span><span class="gallery-expand" aria-hidden="true">↗</span></span></button>
                <button class="gallery-tile" type="button" data-gallery="hanggar"><img src="/assets/halim-hangar.svg" alt="Perbesar ilustrasi: Di balik setiap perjalanan" width="640" height="420" loading="lazy"><span class="gallery-overlay"><span><small>02 / HANGGAR</small><strong>Di balik setiap perjalanan</strong></span><span class="gallery-expand" aria-hidden="true">↗</span></span></button>
                <button class="gallery-tile" type="button" data-gallery="bersama"><img src="/assets/halim-community.svg" alt="Perbesar ilustrasi: Mendekatkan dunia dirgantara" width="640" height="420" loading="lazy"><span class="gallery-overlay"><span><small>03 / KEBERSAMAAN</small><strong>Mendekatkan dunia dirgantara</strong></span><span class="gallery-expand" aria-hidden="true">↗</span></span></button>
            </div>
        </section>

        <section id="informasi" class="information-section" aria-labelledby="information-title">
            <div class="container information-grid">
                <div><p class="eyebrow light">RUANG INFORMASI</p><h2 id="information-title">Sebuah simulasi.<br>Untuk belajar lebih jauh.</h2><p>Halaman ini disiapkan untuk pengujian lokal. Tidak mewakili Lanud Halim Perdanakusuma atau layanan resmi instansi mana pun.</p><a class="button button-outline" href="#beranda">Kembali ke beranda <span aria-hidden="true">↑</span></a></div>
                <div class="information-details"><div class="information-status"><span class="status-dot" aria-hidden="true"></span> LINGKUNGAN LAB LOKAL</div><dl><div><dt>Jenis portal</dt><dd>Demonstrasi tampilan</dd></div><div><dt>Materi</dt><dd>Konten dan ilustrasi contoh</dd></div><div><dt>Layanan resmi</dt><dd>Tidak terhubung</dd></div><div><dt>Pengumpulan data</dt><dd>Tidak tersedia</dd></div></dl><details><summary>Apakah ini situs resmi?<span aria-hidden="true">+</span></summary><p>Bukan. Ini adalah salinan laboratorium dengan tema visual Lanud Halim. Semua berita dan ilustrasi dibuat untuk demonstrasi, tanpa informasi personel, jadwal operasi, atau layanan publik yang nyata.</p></details></div>
            </div>
        </section>
    </main>

    <footer class="site-footer"><div class="container footer-main"><a class="brand brand-footer" href="#beranda"><span class="brand-symbol" aria-hidden="true"><span>H</span></span><span class="brand-name"><small>LANUD</small><strong>HALIM PERDANAKUSUMA</strong><span>Portal simulasi lokal</span></span></a><p>Dirancang untuk belajar, dalam lingkungan lokal.<br>Tanpa afiliasi, layanan, atau publikasi resmi.</p><a class="back-top" href="#beranda">Ke atas <span aria-hidden="true">↑</span></a></div><div class="container footer-bottom"><p>© <?= htmlspecialchars($year, ENT_QUOTES, 'UTF-8') ?> Portal Simulasi Halim</p><p>SIMULASI LOKAL · BUKAN SITUS RESMI</p></div></footer>
    <dialog id="detail-dialog" aria-labelledby="detail-title"><div class="dialog-content"><button class="dialog-close" type="button" aria-label="Tutup detail">Tutup <span aria-hidden="true">×</span></button><img id="detail-image" src="/assets/halim-aviation.svg" alt="" width="1000" height="600"><div class="dialog-copy"><p class="eyebrow" id="detail-category">KONTEN CONTOH</p><h2 id="detail-title">Detail simulasi</h2><div id="detail-body"></div><p class="dialog-disclosure">SIMULASI LOKAL · Materi demonstrasi, bukan publikasi resmi.</p></div></div></dialog>
</body>
</html>
