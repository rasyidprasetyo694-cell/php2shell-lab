(() => {
    'use strict';

    const menuButton = document.querySelector('.menu-button');
    const navigation = document.querySelector('#site-nav');
    const navigationLinks = [...document.querySelectorAll('#site-nav a')];
    const dialog = document.querySelector('#detail-dialog');
    const dialogClose = document.querySelector('.dialog-close');
    const detailTitle = document.querySelector('#detail-title');
    const detailCategory = document.querySelector('#detail-category');
    const detailImage = document.querySelector('#detail-image');
    const detailBody = document.querySelector('#detail-body');
    let returnFocus = null;

    const articles = {
        kegiatan: {
            category: 'KEGIATAN · BERITA CONTOH',
            title: 'Semangat kesiapan, dimulai dari kebersamaan.',
            image: '/assets/halim-aviation.svg',
            alt: 'Ilustrasi digital pesawat angkut generik di landasan',
            paragraphs: [
                'Artikel ini merupakan contoh berita untuk menguji tampilan portal lokal. Ceritanya menggambarkan suasana kerja sama, kedisiplinan, dan kepedulian dalam sebuah lingkungan pangkalan fiktif.',
                'Ilustrasi pesawat dan landasan dibuat khusus untuk demonstrasi. Tidak ada kegiatan, satuan, personel, lokasi operasional, atau jadwal nyata yang dilaporkan melalui halaman ini.',
                'Gunakan kategori kabar, navigasi, dan galeri untuk menjelajahi fungsi antarmuka. Seluruh interaksi berlangsung pada halaman ini tanpa mengirim data ke layanan resmi.'
            ]
        },
        edukasi: {
            category: 'EDUKASI · BERITA CONTOH',
            title: 'Mengenal pesawat, merawat mimpi di angkasa.',
            image: '/assets/halim-hangar.svg',
            alt: 'Ilustrasi hanggar dan pesawat generik untuk edukasi',
            paragraphs: [
                'Rasa ingin tahu menjadi awal perjalanan mengenal dunia penerbangan. Dalam contoh cerita ini, ruang hanggar digambarkan sebagai tempat untuk belajar tentang bentuk pesawat, kerja sama, dan keselamatan secara umum.',
                'Materi ini bersifat ilustratif. Tidak terdapat undangan kunjungan, pendaftaran kegiatan, atau akses ke fasilitas nyata. Semua visual merupakan karya ilustrasi untuk lingkungan uji lokal.',
                'Contoh artikel dapat digunakan untuk memeriksa keterbacaan teks, tampilan gambar, dan perilaku dialog pada layar komputer maupun perangkat seluler.'
            ]
        },
        sosial: {
            category: 'SOSIAL · BERITA CONTOH',
            title: 'Kebersamaan yang tumbuh, pengabdian yang dekat.',
            image: '/assets/halim-community.svg',
            alt: 'Ilustrasi ruang pamer kedirgantaraan untuk masyarakat',
            paragraphs: [
                'Contoh berita ini mengangkat tema kebersamaan dan ruang belajar yang terbuka. Suasana pameran kedirgantaraan menjadi latar ilustratif untuk memperkenalkan cerita kepedulian dan pengabdian.',
                'Tidak ada kegiatan sosial, penyaluran bantuan, atau acara resmi yang diklaim berlangsung. Seluruh isi disusun sebagai materi contoh, tanpa identitas individu atau data peserta.',
                'Portal ini tidak mengumpulkan donasi, informasi pribadi, atau pendaftaran apa pun. Anda dapat menutup dialog untuk kembali menjelajahi tampilan simulasi.'
            ]
        }
    };
    const galleries = {
        landasan: {
            category: 'GALERI · ILUSTRASI 01',
            title: 'Cakrawala di atas landasan',
            image: '/assets/halim-aviation.svg',
            alt: 'Ilustrasi pesawat angkut di landasan dalam cahaya senja',
            paragraphs: ['Ilustrasi digital orisinal pesawat generik dan suasana landasan. Gambar ini bukan foto, peta fasilitas, atau dokumentasi kegiatan resmi.']
        },
        hanggar: {
            category: 'GALERI · ILUSTRASI 02',
            title: 'Di balik setiap perjalanan',
            image: '/assets/halim-hangar.svg',
            alt: 'Ilustrasi ruang hanggar dan pesawat generik',
            paragraphs: ['Komposisi ilustratif sebuah hanggar dan pesawat generik, dibuat untuk kebutuhan visual portal. Tidak menggambarkan tata letak fasilitas nyata.']
        },
        bersama: {
            category: 'GALERI · ILUSTRASI 03',
            title: 'Mendekatkan dunia dirgantara',
            image: '/assets/halim-community.svg',
            alt: 'Ilustrasi ruang pamer dan suasana edukasi dirgantara',
            paragraphs: ['Ilustrasi suasana edukasi kedirgantaraan. Seluruh objek merupakan rekaan visual untuk simulasi lokal, bukan laporan acara atau representasi personel nyata.']
        }
    };

    function closeMenu() {
        navigation?.classList.remove('open');
        menuButton?.setAttribute('aria-expanded', 'false');
    }
    menuButton?.addEventListener('click', () => {
        const opened = navigation.classList.toggle('open');
        menuButton.setAttribute('aria-expanded', String(opened));
    });
    navigationLinks.forEach((link) => link.addEventListener('click', closeMenu));
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') closeMenu();
    });
    window.addEventListener('resize', () => {
        if (window.innerWidth > 850) closeMenu();
    });

    const filterButtons = [...document.querySelectorAll('[data-filter]')];
    const cards = [...document.querySelectorAll('.news-card')];
    const filterStatus = document.querySelector('#filter-status');
    function filterNews(category) {
        filterButtons.forEach((button) => {
            const selected = button.dataset.filter === category;
            button.classList.toggle('selected', selected);
            button.setAttribute('aria-pressed', String(selected));
        });
        let visible = 0;
        cards.forEach((card) => {
            card.hidden = category !== 'semua' && card.dataset.category !== category;
            if (!card.hidden) visible += 1;
        });
        if (filterStatus) filterStatus.textContent = 'Menampilkan ' + visible + ' kabar contoh.';
    }
    filterButtons.forEach((button) => {
        button.addEventListener('click', () => filterNews(button.dataset.filter));
    });
    document.querySelector('#show-all-news')?.addEventListener('click', () => {
        filterNews('semua');
        filterButtons[0]?.focus({ preventScroll: true });
    });

    function showDetail(content, trigger) {
        if (!content || !dialog) return;
        returnFocus = trigger;
        detailTitle.textContent = content.title;
        detailCategory.textContent = content.category;
        detailImage.src = content.image;
        detailImage.alt = content.alt;
        detailBody.replaceChildren(...content.paragraphs.map((text) => {
            const paragraph = document.createElement('p');
            paragraph.textContent = text;
            return paragraph;
        }));
        dialog.showModal();
        dialog.scrollTop = 0;
        document.body.classList.add('dialog-open');
        dialogClose.focus({ preventScroll: true });
    }
    document.querySelectorAll('[data-article]').forEach((button) => {
        button.addEventListener('click', () => showDetail(articles[button.dataset.article], button));
    });
    document.querySelectorAll('[data-gallery]').forEach((button) => {
        button.addEventListener('click', () => showDetail(galleries[button.dataset.gallery], button));
    });
    dialogClose?.addEventListener('click', () => dialog.close());
    dialog?.addEventListener('click', (event) => {
        if (event.target !== dialog) return;
        const bounds = dialog.getBoundingClientRect();
        if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
    });
    dialog?.addEventListener('close', () => {
        document.body.classList.remove('dialog-open');
        returnFocus?.focus({ preventScroll: true });
    });

    if ('IntersectionObserver' in window) {
        const sectionObserver = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) return;
                navigationLinks.forEach((link) => {
                    const active = link.hash === '#' + entry.target.id;
                    link.classList.toggle('active', active);
                    if (active) link.setAttribute('aria-current', 'location');
                    else link.removeAttribute('aria-current');
                });
            });
        }, { rootMargin: '-100px 0px -55% 0px', threshold: 0.05 });
        ['beranda', 'profil', 'kabar', 'galeri', 'informasi'].forEach((id) => {
            const section = document.getElementById(id);
            if (section) sectionObserver.observe(section);
        });
    }
})();
